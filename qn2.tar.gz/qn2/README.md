Programs for part a and part b are in 2 different directories.
Run "make", and then "make run" in each directory to compile and run the programs.
